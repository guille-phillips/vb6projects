This archive contains all the ROM images from:

 1. files on disks, on the web ('kopie_van_disk/')
 2. and those made from copied EPROMs ('kopie_van_eprom/')
 3. those from reading in original ROMs/EPROMs ('origineel/').

I will separately maintain these three until I'm a bit more sure which ROM images are ok.
In the originals section, most have just been encountered once, by me.
This means there's some overlap but not much.

Possible problems with these sources:
 ad 1. These files can be corrupt when they were written to disk, from bad RAM or bad copying programs. Some such programs copying ROMs to disk are know to corrupt the ROM image. Reading the files from disk should be fine as data on disks is stored with CRCs.

 ad 2. These are more reliable in the sense that they were used, but I've experienced unprogramming of bits, so this means they can become unreliable even if they were ok at some time. Also, that they were used doesn't mean the original ROM image was completely ok...

 ad 3. Bit unprogramming is a real issue, so although I consider files made from reading in original EPROMs/ROMs the most reliable, this might not be so any more in a few years time when trying to read in a EPROM. Therefore, the date of making the EPROM (estimate by the copyright date), and date of reading it in, should be noted...

All in the all, the only real check for correctness is in numbers (from hopefully different sources).


I've had almost no contributions for any of these sections btw. (shame on you!).

W.Scholten
