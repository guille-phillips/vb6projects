-------------------------------------------------------------------------------
This archive  contains all the  ROM images I  found on the net  and on
loads of disks.  ROMs that appeared more than once  have a .files file
with them, saying  how many times they were found.  This should give a
better idea of reliability.

Images made from  copies of (EP)ROMs and of  original (EP)ROMs will be
merged in later.

Documentation from 'the bbc lives'  that was in the ROM directories is
still there. Big  files could be placed in a  separate doc directory I
suppose. In the  end that will probably be  necessary but there aren't
many ROMs with full docs at the moment...

If you try a ROM, let me know if it works or not!

Criteria to be included in this archive are:

 - ROMs should  be for the BBC  micro.  ROMs solely  meant for related
   microcomputers  from  Acorn   (Electron/BBC  Master  etc.)  do  not
   qualify. I can't do everything...



W.Scholten (email swhs-web @ xs4all.nl)

